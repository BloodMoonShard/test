</div>
<!-- /#wrapper -->


<!-- Bootstrap Core JavaScript -->
<script src="/assets/a/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="/assets/a/js/plugins/metisMenu/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="/assets/a/js/plugins/morris/raphael.min.js"></script>
<!--<script src="/assets/a/js/plugins/morris/morris.min.js"></script>-->
<!--<script src="/assets/a/js/plugins/morris/morris-data.js"></script>-->

<!-- Custom Theme JavaScript -->
<script src="/assets/a/js/sb-admin-2.js"></script>

<!-- jQuery Sortable -->
<script src="/assets/a/js/jquery.sortable.js"></script>

</body>

</html>