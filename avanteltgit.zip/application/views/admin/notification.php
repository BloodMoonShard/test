<div id="page-wrapper" style="min-height: 704px;">
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default">
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="alert alert-<?= $status_notif; ?>">
                        <?= $msg_notif; ?>
                    </div>
                </div>
                <a href="<?php echo $back_link; ?>" class="btn btn-info">Вернуться</a>
                <!-- .panel-body -->
            </div>
        </div>
        <!-- /.panel -->
    </div>
</div>


