    <section class="grid-services">
        <div class="grand-bg">
        <div class="container">
            <div class="wrapper-block-services clearfix">
                <a href="/type/house">
                <div class="block-services">
                    <div class="img-service cottage-house">
                        <div class="text">
                            Коттеджи, дома
                        </div>
                    </div>
                </div>
                </a>
                <a href="#">
                <div class="block-services">
                    <div class="img-service land">
                        <div class="text">
                            Земельные участки
                        </div>
                    </div>
                </div>
                </a>
                <a href="#">
                <div class="block-services">
                    <div class="img-service aparts">
                        <div class="text">
                            Квартиры
                        </div>
                    </div>
                </div>
                </a>
                <a href="/type/building">
                <div class="block-services">
                    <div class="img-service building">
                        <div class="text">
                            Строительство
                        </div>
                    </div>
                </div>
                </a>
                <a href="#">
                <div class="block-services">
                    <div class="img-service real-estate">
                        <div class="text">
                            Коммерческая <Br/> недвижимость
                        </div>
                    </div>
                </div>
                </a>
                <a href="#">
                <div class="block-services">
                    <div class="img-service overseas-real-estate">
                        <div class="text">
                            Зарубежная <Br/> недвижимость
                        </div>
                    </div>
                </div>
                </a>
                <a href="/legal_services">
                <div class="block-services">
                    <div class="img-service legal-services">
                        <div class="text">
                            Юридические услуги
                        </div>
                    </div>
                </div>
                </a>
                <a href="/credit_broker">
                <div class="block-services">
                    <div class="img-service credit">
                        <div class="text">
                            Кредитный брокер
                        </div>
                    </div>
                </div>
                </a>
                <a href="/partners">
                <div class="block-services">
                    <div class="img-service partner">
                        <div class="text">
                            Партнеры
                        </div>
                    </div>
                </div>
                </a>
            </div>
        </div>
        </div>
    </section>
