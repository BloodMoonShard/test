<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Object_type_model extends My_Model{

    public $table_name = 'objects_type';
    public $primary_key = 'id_objects_type';


}