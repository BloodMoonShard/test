<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//Config for library Auth
// Types both, login, email
$config['type_auth'] = 'both';

$config['login_error'] = 'Login or Password wrong';