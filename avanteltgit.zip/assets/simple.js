$(function () {
	$('[name="city"]').kladr({
		type: $.kladr.type.city
	});
});