$(function () {
	$('[name="address"]').kladr({
		oneString: true
	});
});